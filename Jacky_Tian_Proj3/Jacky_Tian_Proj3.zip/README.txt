README.txt

CS194-26
Jacky Tian

HW3

Dependencies: 
	numpy
	scipy
	skimage
	opencv

main.py:
	file used to run each part of the project
	list of files can be adapted to run on other images

hybrid_image.py
	file containing the functions for creating gaussian and laplacian stacks, along with hybrid image function

proj3.py
	file containing rest of the functions such as blending, masking, sharpening