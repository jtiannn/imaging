README.txt

CS194-26
Jacky Tian

HW1

Dependencies: 
	numpy
	scipy
	skimage

main.py:
	file used to call run() in colorize.py
	list of files can be adapted to run on other images

colorize.py
	file containing the functions to align and colorize rgb images