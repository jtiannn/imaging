#CS194-26
#Jacky Tian

from colorize import *

files = ['cathedral.jpg', 'monastery.jpg', 'settlers.jpg', 'nativity.jpg', 
		'harvesters.tif', 'emir.tif', 'icon.tif', 'lady.tif', 'self_portrait.tif',
		'three_generations.tif', 'train.tif', 'turkmen.tif', 'village.tif',
		'porch.jpg', 'house.jpg', 'guardhouse.jpg']

run(files, False)